PR: Split `TondinoContext` into focused contexts and migrate consumers
===================================================================

Summary
-------
This branch refactors the monolithic `TondinoContext` into focused contexts/hooks and migrates major consumers:

- Added focused contexts: `UIContext`, `SelectionContext`, `NotificationsContext`, `ChatContext`, `StatsContext`.
- Kept `AuthContext` as the single source of truth for auth/profile.
- Composed providers via `TondinoProvider` and removed the legacy `useTondino()` wrapper.
- Migrated many components to use focused hooks (`useUI`, `useSelection`, `useStats`, `useChat`, `useNotifications`, `useAuth`).
- Added migration guide: `tondino-frontend/docs/USE_TONDINO_MIGRATION.md` and `CHANGELOG.md`.
- Fixed TypeScript issues surfaced during migration and verified TypeScript, build, and preview smoke tests.

Files changed (high-level)
-------------------------
- Added: `src/context/UIContext.tsx`, `SelectionContext.tsx`, `NotificationsContext.tsx`, `ChatContext.tsx`, `StatsContext.tsx`.
- Updated: `src/context/TondinoContext.tsx` (removed legacy wrapper), many components migrated to focused hooks.
- Docs: `tondino-frontend/docs/USE_TONDINO_MIGRATION.md`, `tondino-frontend/CHANGELOG.md`, `PR_BODY.md`.

How to import/apply this branch (if pushing to origin isn't possible from this machine)
----------------------------------------------------------------------------------
Option A — import the bundle into an existing clone:

```bash
# in your local clone of the remote repo
cp /path/to/refactor-contexts-split.bundle ./
git fetch ./refactor-contexts-split.bundle refactor/contexts-split:refs/heads/refactor/contexts-split
git checkout refactor/contexts-split
```

Option B — clone directly from the bundle into a new working directory:

```bash
git clone /path/to/refactor-contexts-split.bundle -b refactor/contexts-split tondino-refactor
cd tondino-refactor
```

Notes on pushing
----------------
- The local push failed due to SSH permission issues (`git@github.com` publickey). You can:
  - Configure SSH keys on this machine with GitHub, or
  - Push from another machine that has write access, or
  - Import the bundle into a machine/CI with credentials and push the branch and open a PR.

Suggested PR title
------------------
refactor(context): split TondinoContext into focused contexts and migrate consumers

Suggested PR body (short)
------------------------
This PR splits the monolithic `TondinoContext` into several smaller, focused React contexts and hooks to reduce re-render surface and give each responsibility a single owner. It migrates most consumers to the new hooks, removes the legacy `useTondino()` wrapper, and fixes related TypeScript issues. Includes a migration guide and changelog.

Checklist
---------
- [x] TypeScript check passes
- [x] Production build succeeds
- [x] Preview smoke tests for key routes return 200
- [ ] Finalize any remaining consumer migrations (quick grep to confirm)
- [ ] Run profiling + targeted memoization if needed
- [ ] Open PR and request review
